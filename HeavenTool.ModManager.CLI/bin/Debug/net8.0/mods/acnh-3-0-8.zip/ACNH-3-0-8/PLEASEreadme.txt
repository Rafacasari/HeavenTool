Jubbsticks' Update Mod - v3.0.8
Thank you for downloading!
---

NOTE: Before you do anything, please make a backup of your game, just to be safe. Also, keep in mind that removing or disabling the mod will *permanently* any 3.0 items you may have obtained, so you should definitely backup your island if you plan to disable the mod and you want to be able to recover your items.

---
Installation Instructions, for atmosphere.
 - If you have a previous version of this mod, you can install faster by installing the "Update/atmosphere" folder instead.
 - If this is your first time installing, just drag and drop the atmosphere folder onto the root of your SD card. Merge all folders.
 - If you have conflicting files (from other mods) while merging, I would suggest reviewing the below list of common-conflicts to understand what each of these files does. These tend to be important for 3.0.0's functioning, but if you prefer the function provided by another mod you may pick and choose which files to include--however, if certain files do not match other players, you cannot connect online to them, making online functionality impossible.

---

Common-Conflicts: 
Bcsv
 - FgMainParam.bcsv - This file is necessary for new trees to work.
 - ItemKind.bcsv - This file is necessary for items to stack to 99, and for manila clams to stack.
 - ItemOutfitInfo.bcsv - This file is necessary for the new tool types to be unbreakable.
 - ItemParam.bcsv - This file is VERY important, it includes item data for every new item.
 - ItemRemake.bcsv - This file allows for all the added customization options.
EventFlow
 - Ftr_Working.bfevfl - This file is necessary for Bulk Crafting fish bait.
 - SNPC_rcm_11_BuyDIYBook - This file is necessary for the Super Smoothies Recipes to be purchasable in the nook's cabinet.
Model
 - None of the files which may conflict with other mods in the Model folder are necessary for the mod to function. Feel free to replace the default models with whatever you like. Changing these also won't affect online compatability.
System
 - ResourceSizeTable.srsizetable - PLEASE READ THE BELOW INFO

**IMPORTANT** RSTB Patch Info (ResourceSizeTable.srsizetable)
- The mod comes with an RSTB file (in the System folder) that makes main-game performance MUCH better, however it causes the buildings on Happy Home Paradise to become invisible. If you want to play the DLC, I would suggest switching to the Universal RSTB before heading to the archipelago, but using the included patch when you play on your island.  The mod may have issues loading icons, dialouge, and some models if you play with Universal RSTB instead of the included patch on the main island.
-If you want play with other mods installed at the same time, I would suggest creating your own RSTB patch using one of the several RSTB patcher tools available online. If you don't want to make your own patch, the performance with the included RSTB file will still be better than Universal, but adding other mods into the mix can impact performance with either one.

---
